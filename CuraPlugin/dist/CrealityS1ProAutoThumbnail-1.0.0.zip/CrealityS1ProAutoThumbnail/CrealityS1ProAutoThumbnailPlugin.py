import base64
import re
import textwrap
import types
import os
from typing import Any, Dict, Optional

try:
    from PyQt6.QtCore import QObject, pyqtProperty, pyqtSignal, pyqtSlot
except Exception:
    from PyQt5.QtCore import QObject, pyqtProperty, pyqtSignal, pyqtSlot

from UM.Extension import Extension
from UM.Logger import Logger
from UM.PluginRegistry import PluginRegistry
from UM.i18n import i18nCatalog

try:
    from cura.CuraApplication import CuraApplication
    from cura.Snapshot import Snapshot
except Exception:
    CuraApplication = None
    Snapshot = None

try:
    from PyQt6.QtCore import QByteArray, QBuffer, QIODevice
except Exception:
    try:
        from PyQt5.QtCore import QByteArray, QBuffer, QIODevice
    except Exception:
        QByteArray = None
        QBuffer = None
        QIODevice = None


catalog = i18nCatalog("cura")


class CrealityS1ProAutoThumbnailPlugin(QObject, Extension):
    _plugin_block_begin = ";CREALITY_S1_AUTO_THUMBNAIL_BEGIN"
    _plugin_block_end = ";CREALITY_S1_AUTO_THUMBNAIL_END"

    preferencesChanged = pyqtSignal()

    def __init__(self, parent = None) -> None:
        QObject.__init__(self, parent)
        Extension.__init__(self)

        if CuraApplication is None:
            self._application = None
            return

        self._application = CuraApplication.getInstance()
        self._preferences = self._application.getPreferences()
        self._settings_dialog = None
        self._registerPreferences()

        self.setMenuName("S1 Pro Auto Thumbnail")
        self.addMenuItem("Enable Auto Thumbnail", self._enablePlugin)
        self.addMenuItem("Disable Auto Thumbnail", self._disablePlugin)
        self.addMenuItem("Settings", self.showSettings)

        self._application.initializationFinished.connect(self._patchOutputDevices)
        self._application.getOutputDeviceManager().outputDevicesChanged.connect(self._patchOutputDevices)

    def _registerPreferences(self) -> None:
        self._preferences.addPreference("creality_s1_auto_thumbnail/enabled", True)
        self._preferences.addPreference("creality_s1_auto_thumbnail/size", 300)
        self._preferences.addPreference("creality_s1_auto_thumbnail/jpeg_quality", 85)
        self._preferences.addPreference("creality_s1_auto_thumbnail/creality_tail", " 1 197 500")
        self._preferences.addPreference("creality_s1_auto_thumbnail/line_prefix", "; ")
        self._preferences.addPreference("creality_s1_auto_thumbnail/line_len", 76)
        self._preferences.addPreference("creality_s1_auto_thumbnail/enable_leveling", False)
        self._preferences.addPreference("creality_s1_auto_thumbnail/leveling_mode", "use_saved_mesh")

    def _enablePlugin(self) -> None:
        self._preferences.setValue("creality_s1_auto_thumbnail/enabled", True)
        self.preferencesChanged.emit()
        Logger.log("i", "S1Pro auto thumbnail: enabled.")

    def _disablePlugin(self) -> None:
        self._preferences.setValue("creality_s1_auto_thumbnail/enabled", False)
        self.preferencesChanged.emit()
        Logger.log("i", "S1Pro auto thumbnail: disabled.")

    def _createSettingsDialog(self) -> None:
        plugin_path = PluginRegistry.getInstance().getPluginPath(self.getPluginId())
        if not plugin_path:
            Logger.log("e", "S1Pro auto thumbnail: plugin path not found.")
            return

        qml_path = os.path.join(plugin_path, "SettingsDialog.qml")
        self._settings_dialog = self._application.createQmlComponent(qml_path, {"manager": self})

    def showSettings(self) -> None:
        if self._settings_dialog is None:
            self._createSettingsDialog()
        if self._settings_dialog is not None:
            self._settings_dialog.show()

    def _patchOutputDevices(self) -> None:
        if self._application is None:
            return

        manager = self._application.getOutputDeviceManager()
        for device in manager.getOutputDevices():
            perform_write = getattr(device, "_performWrite", None)
            if (
                perform_write is None
                or getattr(device, "_creality_s1_auto_patched", False)
                or not self._isSupportedOutputDevice(device)
            ):
                continue

            original_perform_write = perform_write

            def wrapped_perform_write(device_self, *args, __original = original_perform_write, **kwargs):
                try:
                    format_data = args[1] if len(args) > 1 and isinstance(args[1], dict) else None
                    if self._shouldProcessWrite(format_data):
                        self._processSceneGcode()
                except Exception as ex:
                    Logger.logException("e", f"S1Pro auto thumbnail: pre-write processing failed: {ex}")
                return __original(*args, **kwargs)

            device._performWrite = types.MethodType(wrapped_perform_write, device)
            device._creality_s1_auto_patched = True
            Logger.log("d", "S1Pro auto thumbnail: patched output device %s", device.getId())

    def _isSupportedOutputDevice(self, device: Any) -> bool:
        device_id = str(getattr(device, "getId", lambda: "")())
        class_name = device.__class__.__name__
        return device_id == "local_file" or class_name == "RemovableDriveOutputDevice"

    def _shouldProcessWrite(self, format_data: Optional[Dict[str, Any]]) -> bool:
        if not self._preferences.getValue("creality_s1_auto_thumbnail/enabled"):
            return False

        if not isinstance(format_data, dict):
            return True

        mime_type = str(format_data.get("mime_type", "")).lower()
        extension = str(format_data.get("extension", "")).lower()
        identifier = str(format_data.get("id", "")).lower()
        description = str(format_data.get("description", "")).lower()

        return (
            mime_type == "text/x-gcode"
            or extension == "gcode"
            or "gcode" in identifier
            or "g-code" in description
        )

    def _processSceneGcode(self) -> None:
        if self._application is None:
            return

        scene = self._application.getController().getScene()
        if not hasattr(scene, "gcode_dict"):
            return

        gcode_dict = getattr(scene, "gcode_dict")
        if not gcode_dict:
            return

        active_build_plate_id = self._application.getMultiBuildPlateModel().activeBuildPlate
        gcode_list = gcode_dict.get(active_build_plate_id)
        if not gcode_list:
            return

        original_gcode = "\n".join(gcode_list)
        processed_gcode = self._buildProcessedGcode(original_gcode)
        if processed_gcode == original_gcode:
            return

        gcode_dict[active_build_plate_id] = [processed_gcode]
        setattr(scene, "gcode_dict", gcode_dict)

    def _buildProcessedGcode(self, gcode: str) -> str:
        gcode = self._stripManagedBlock(gcode)

        if self._preferences.getValue("creality_s1_auto_thumbnail/enable_leveling"):
            leveling_mode = self._preferences.getValue("creality_s1_auto_thumbnail/leveling_mode") or "use_saved_mesh"
            gcode = self._injectLeveling(gcode, leveling_mode)
        else:
            gcode = self._stripManagedLeveling(gcode)

        if re.search(r"(?im)^\s*;\s*jpg\s+begin\s+\d+\*\d+\s+\d+", gcode):
            return gcode

        if Snapshot is None:
            Logger.log("w", "S1Pro auto thumbnail: Snapshot API not available.")
            return gcode

        if QByteArray is None or QBuffer is None or QIODevice is None:
            Logger.log("w", "S1Pro auto thumbnail: Qt buffer API not available.")
            return gcode

        size = int(self._preferences.getValue("creality_s1_auto_thumbnail/size"))
        quality = int(self._preferences.getValue("creality_s1_auto_thumbnail/jpeg_quality"))
        tail = self._preferences.getValue("creality_s1_auto_thumbnail/creality_tail") or ""
        line_prefix = self._preferences.getValue("creality_s1_auto_thumbnail/line_prefix") or "; "
        line_len = int(self._preferences.getValue("creality_s1_auto_thumbnail/line_len"))

        image = None
        try:
            image = Snapshot.snapshot(size, size)
        except Exception:
            try:
                image = Snapshot().snapshot(size, size)
            except Exception as ex:
                Logger.log("w", f"S1Pro auto thumbnail: Snapshot failed: {ex}")
                return gcode

        if image is None:
            Logger.log("w", "S1Pro auto thumbnail: Snapshot returned None.")
            return gcode

        image_bytes = self._encodeSnapshotToJpg(image, quality)
        if not image_bytes:
            Logger.log("w", "S1Pro auto thumbnail: Failed to encode JPG.")
            return gcode

        b64 = base64.b64encode(image_bytes).decode("ascii")
        b64_lines = textwrap.wrap(b64, line_len)
        b64_block = "\n".join(f"{line_prefix}{line}" for line in b64_lines)

        header = f"; jpg begin {size}*{size} {len(image_bytes)}{tail}".rstrip()
        block = "\n".join(
            [
                self._plugin_block_begin,
                header,
                b64_block,
                "; jpg end",
                self._plugin_block_end
            ]
        )

        match = re.search(r"(?im)^\s*;FLAVOR:", gcode)
        if match:
            return gcode[:match.start()] + block + "\n" + gcode[match.start():]
        return block + "\n" + gcode

    def _encodeSnapshotToJpg(self, image, quality: int) -> bytes:
        data = QByteArray()
        buffer = QBuffer(data)
        buffer.open(QIODevice.OpenModeFlag.WriteOnly)
        success = image.save(buffer, "JPG", quality)
        buffer.close()
        if not success or data.size() <= 0:
            return b""
        return bytes(data)

    def _injectLeveling(self, gcode: str, leveling_mode: str) -> str:
        if re.search(r"(?im)^\s*G29\b", gcode) or re.search(r"(?im)^\s*M420\s+S1\b", gcode):
            return gcode

        match = re.search(r"(?im)^\s*G28\b.*$", gcode)
        if not match:
            return gcode

        insert_pos = match.end()
        if leveling_mode == "probe_now":
            leveling_lines = "\nG29 ; Auto Bed Leveling (probe mesh now)\n"
        else:
            leveling_lines = "\n;CREALITY_S1_AUTO_LEVELING_BEGIN\nM420 S1 ; Enable saved mesh leveling\n;CREALITY_S1_AUTO_LEVELING_END\n"

        if leveling_mode == "probe_now":
            leveling_lines = "\n;CREALITY_S1_AUTO_LEVELING_BEGIN\nG29 ; Auto Bed Leveling (probe mesh now)\n;CREALITY_S1_AUTO_LEVELING_END\n"

        return gcode[:insert_pos] + leveling_lines + gcode[insert_pos:]

    def _stripManagedBlock(self, gcode: str) -> str:
        block_pattern = re.compile(
            rf"(?ims)^\s*{re.escape(self._plugin_block_begin)}\s*$.*?^\s*{re.escape(self._plugin_block_end)}\s*$\n?"
        )
        return block_pattern.sub("", gcode)

    def _stripManagedLeveling(self, gcode: str) -> str:
        leveling_pattern = re.compile(
            r"(?ims)\n?;\s*CREALITY_S1_AUTO_LEVELING_BEGIN\s*$.*?^\s*;\s*CREALITY_S1_AUTO_LEVELING_END\s*$\n?"
        )
        return leveling_pattern.sub("\n", gcode)

    @pyqtProperty(bool, notify = preferencesChanged)
    def enabled(self) -> bool:
        return bool(self._preferences.getValue("creality_s1_auto_thumbnail/enabled"))

    @pyqtProperty(int, notify = preferencesChanged)
    def size(self) -> int:
        return int(self._preferences.getValue("creality_s1_auto_thumbnail/size"))

    @pyqtProperty(int, notify = preferencesChanged)
    def jpegQuality(self) -> int:
        return int(self._preferences.getValue("creality_s1_auto_thumbnail/jpeg_quality"))

    @pyqtProperty(int, notify = preferencesChanged)
    def lineLength(self) -> int:
        return int(self._preferences.getValue("creality_s1_auto_thumbnail/line_len"))

    @pyqtProperty(str, notify = preferencesChanged)
    def linePrefix(self) -> str:
        return str(self._preferences.getValue("creality_s1_auto_thumbnail/line_prefix") or "; ")

    @pyqtProperty(str, notify = preferencesChanged)
    def crealityTail(self) -> str:
        return str(self._preferences.getValue("creality_s1_auto_thumbnail/creality_tail") or "")

    @pyqtProperty(bool, notify = preferencesChanged)
    def levelingEnabled(self) -> bool:
        return bool(self._preferences.getValue("creality_s1_auto_thumbnail/enable_leveling"))

    @pyqtProperty(str, notify = preferencesChanged)
    def levelingMode(self) -> str:
        return str(self._preferences.getValue("creality_s1_auto_thumbnail/leveling_mode") or "use_saved_mesh")

    @pyqtSlot(bool)
    def setEnabled(self, value: bool) -> None:
        self._preferences.setValue("creality_s1_auto_thumbnail/enabled", value)
        self.preferencesChanged.emit()

    @pyqtSlot(int)
    def setSize(self, value: int) -> None:
        self._preferences.setValue("creality_s1_auto_thumbnail/size", max(64, min(512, int(value))))
        self.preferencesChanged.emit()

    @pyqtSlot(int)
    def setJpegQuality(self, value: int) -> None:
        self._preferences.setValue("creality_s1_auto_thumbnail/jpeg_quality", max(40, min(95, int(value))))
        self.preferencesChanged.emit()

    @pyqtSlot(int)
    def setLineLength(self, value: int) -> None:
        self._preferences.setValue("creality_s1_auto_thumbnail/line_len", max(40, min(120, int(value))))
        self.preferencesChanged.emit()

    @pyqtSlot(str)
    def setLinePrefix(self, value: str) -> None:
        self._preferences.setValue("creality_s1_auto_thumbnail/line_prefix", value or "; ")
        self.preferencesChanged.emit()

    @pyqtSlot(str)
    def setCrealityTail(self, value: str) -> None:
        self._preferences.setValue("creality_s1_auto_thumbnail/creality_tail", value or "")
        self.preferencesChanged.emit()

    @pyqtSlot(bool)
    def setLevelingEnabled(self, value: bool) -> None:
        self._preferences.setValue("creality_s1_auto_thumbnail/enable_leveling", value)
        self.preferencesChanged.emit()

    @pyqtSlot(str)
    def setLevelingMode(self, value: str) -> None:
        if value not in ("use_saved_mesh", "probe_now"):
            value = "use_saved_mesh"
        self._preferences.setValue("creality_s1_auto_thumbnail/leveling_mode", value)
        self.preferencesChanged.emit()
