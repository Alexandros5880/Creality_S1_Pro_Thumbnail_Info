import QtQuick 2.10
import QtQuick.Controls 2.3
import QtQuick.Window 2.2

import UM 1.5 as UM
import Cura 1.1 as Cura

Window
{
    UM.I18nCatalog { id: catalog; name: "cura" }

    id: baseDialog
    title: "S1 Pro Auto Thumbnail"
    visible: false
    modality: Qt.ApplicationModal
    minimumWidth: 520 * screenScaleFactor
    minimumHeight: 520 * screenScaleFactor
    width: minimumWidth
    height: minimumHeight
    color: UM.Theme.getColor("main_background")

    Item
    {
        anchors.fill: parent
        anchors.margins: UM.Theme.getSize("default_margin").width

        Column
        {
            anchors.fill: parent
            spacing: UM.Theme.getSize("default_margin").height

            UM.Label
            {
                width: parent.width
                wrapMode: Text.WordWrap
                text: "Automatic Creality JPG thumbnail injection for G-code exports."
            }

            CheckBox
            {
                text: "Enable auto thumbnail"
                checked: manager.enabled
                onToggled: manager.setEnabled(checked)
            }

            Row
            {
                spacing: UM.Theme.getSize("default_margin").width

                UM.Label { text: "Thumbnail size" }
                SpinBox
                {
                    from: 64
                    to: 512
                    value: manager.size
                    onValueModified: manager.setSize(value)
                }
            }

            Row
            {
                spacing: UM.Theme.getSize("default_margin").width

                UM.Label { text: "JPEG quality" }
                SpinBox
                {
                    from: 40
                    to: 95
                    value: manager.jpegQuality
                    onValueModified: manager.setJpegQuality(value)
                }
            }

            Row
            {
                spacing: UM.Theme.getSize("default_margin").width

                UM.Label { text: "Base64 line length" }
                SpinBox
                {
                    from: 40
                    to: 120
                    value: manager.lineLength
                    onValueModified: manager.setLineLength(value)
                }
            }

            Column
            {
                spacing: UM.Theme.getSize("narrow_margin").height

                UM.Label { text: "Line prefix" }
                TextField
                {
                    width: parent.width
                    text: manager.linePrefix
                    onEditingFinished: manager.setLinePrefix(text)
                }
            }

            Column
            {
                spacing: UM.Theme.getSize("narrow_margin").height

                UM.Label { text: "Creality tail numbers" }
                TextField
                {
                    width: parent.width
                    text: manager.crealityTail
                    onEditingFinished: manager.setCrealityTail(text)
                }
            }

            CheckBox
            {
                id: levelingCheck
                text: "Inject bed leveling command"
                checked: manager.levelingEnabled
                onToggled: manager.setLevelingEnabled(checked)
            }

            Row
            {
                enabled: levelingCheck.checked
                spacing: UM.Theme.getSize("default_margin").width

                UM.Label { text: "Leveling mode" }
                ComboBox
                {
                    model: [
                        { text: "Use saved mesh (M420 S1)", value: "use_saved_mesh" },
                        { text: "Probe now (G29)", value: "probe_now" }
                    ]
                    textRole: "text"
                    currentIndex: manager.levelingMode === "probe_now" ? 1 : 0
                    onActivated: manager.setLevelingMode(model[index].value)
                }
            }

            Item
            {
                width: 1
                height: 1
            }

            Row
            {
                spacing: UM.Theme.getSize("default_margin").width

                Cura.PrimaryButton
                {
                    text: catalog.i18nc("@action:button", "Close")
                    onClicked: baseDialog.hide()
                }
            }
        }
    }
}
